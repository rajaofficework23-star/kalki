# KalkiChat Web v1 💬

Browser version of KalkiChat — office PC se chat karne ke liye.
Static site hai (HTML/CSS/JS), **koi build step nahi**. GitHub Pages (free) par host karo.

## Files

| File | Kaam |
|------|------|
| `index.html` | UI shell (saari screens) |
| `styles.css` | Dark WhatsApp-jaisa UI |
| `app.js` | Poori app logic (login, chats, E2E, sessions) |
| `crypto.js` | Crypto: X25519 + Tink-HPKE + AES-GCM + PBKDF2 + key validation. **Asli Tink (Java) ke against dono direction me verified.** |
| `firebase-config.js` | Firebase project `kalkichat-dc32b` ka config (apiKey APK se nikali hui — wahi jo Android app me hai) |
| `vendor/` | Firebase JS SDK 10.14.1 (app/auth/firestore compat) — offline kaam karega, CDN ki zaroorat nahi |

## Kya kaam karta hai (v1)

- **Key login** — wahi `<password>-<24 HEX>` key, 30-day validity, clock-rollback guard. Galat key par wahi message jo phone me aata hai.
- **Web PIN lock** — pehli baar 6-digit PIN set hota hai. Har naye tab me PIN maangega. PIN bhool gaye to logout karke dobara login.
- **Username + password** — key → username → password. Naya username ho to password set karo; purana ho to verify. Verifier `users/{uid}.pwd = {saltB64, hashB64, iter}` me (PBKDF2-HMAC-SHA256, 100k) — phone app (v7) ke saath same field names.
- **Backup restore** — "Backup PIN se purani chats lao": phone ke backup ko PIN se kholkar HPKE private key import → purani chats decrypt hokar dikhengi (read-only).
- **E2E text chat** — 1:1 chats (nayi chats full send/receive; purani phone-wali chats read-only) aur groups (read).
- **Ticks** — ✓ bheja, ✓✓ delivered. Timestamps, online/last-seen, typing indicator.
- **Status** — text status dekho + lagao (24h).
- **📢 Broadcasts** — read-only announcements.
- **Sessions + remote logout** — login par `sessions/{uid}/devices/{sid}` banta hai, har 60s heartbeat. Phone se session delete karoge to PC par turant logout + "Phone se logout kiya gaya 📱".
- **Logout button** — session doc delete + local state clear + Firebase signOut → key-login screen.

## Kya NAHI hai (v1 me out of scope)

P2P photo/video/voice, games, nudge, voice-to-text, app lock, view-once. Sirf text chat rock-solid hai.

## Deploy — GitHub Pages (free, 5 min)

1. GitHub par naya **public** repo banao (e.g. `kalkichat-web`).
2. Is folder ki saari files (`index.html`, `styles.css`, `app.js`, `crypto.js`, `firebase-config.js`, `vendor/`) repo me upload karo (web se drag-drop bhi chalega).
3. Repo → **Settings → Pages** → Source: `Deploy from a branch` → Branch: `main` → Save.
4. URL milega: `https://<tumhara-username>.github.io/kalkichat-web/` — office PC ke browser me kholo.

> `file://` se kholne par bhi chalega (sab kuch local hai), lekin Firebase Auth ke liye `https` (Pages) recommended hai.

## Firebase console me 2 zaroori steps

### 1. Authorized domains (nahi kiya to login fail hoga)
- Firebase console → **Authentication → Settings → Authorized domains** → **Add domain**
- `tumhara-username.github.io` add karo.

### 2. API key restriction check
- Google Cloud Console → **APIs & Services → Credentials** → API key kholo.
- Agar **Application restrictions → Android apps** lagi hai to web se request reject hogi.
- Fix: restrictions me **HTTP referrers** add karo → `https://tumhara-username.github.io/*`, ya restrictions hata do.
- (API key waise bhi public hoti hai — ye sirf abuse rokne ke liye hai.)

### 3. Firestore Rules publish (agar abhi tak nahi kiya)
- `files/firestore.rules.txt` (latest) → Firebase console → **Firestore Database → Rules** → paste → **Publish**.
- Isme `sessions/{uid}/devices/{sid}` wala block hai — remote logout isi se chalega.

## 6pm interop test checklist (phone ↔ PC)

1. Dono par same key se login karo.
2. **PC se nayi chat**: phone ke username se chat kholo → PC se message bhejo → phone par aana chahiye (decrypt hokar).
3. **Phone se reply**: phone se jawab do → PC par aana chahiye + ✓✓ ticks.
4. **Purani chats**: PC par backup PIN se restore → purani chats dikhni chahiye (read-only banner ke saath).
5. **Remote logout**: phone me sessions me jao → Web session delete karo → PC par turant "Phone se logout kiya gaya 📱" aakar logout hona chahiye.
6. **PIN lock**: PC par tab band karke dobara kholo → PIN maangna chahiye.

## Honest notes

- **E2E crypto asli Tink ke against verified hai** (Java Tink 1.18.0 se dono direction encrypt/decrypt test kiya gaya). Phir bhi phone↔PC test zaroori hai — wahi final gate hai.
- **Purani (phone ki) chats PC par read-only hain.** Wajah: Firestore rules sirf participants ko likhne dete hain, aur web ka uid alag hai. Nayi chats (PC se shuru) me full send/receive hai. Full linked-device sending v2 me aayega.
- **P2P media (photo/video/voice) web par nahi hai** — sirf text.
- **Backup PIN bhool gaye to backup bekaar** — PIN kahin store nahi hota (Signal model).
- Sab secrets (keys, PIN verifier) sirf browser me rehte hain — server par kuch nahi jata.
